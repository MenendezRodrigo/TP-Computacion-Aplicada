#!/bin/bash


directorios=()
validos=()
destino=""

uso() {
      echo "usage: $0 <origen> -d <destino>"
      echo "-d destino donde guardar los backup."
      echo "-help muestra esta ayuda."
}

while [ $# -gt 0 ] ; do
  case $1 in 
    -help|-h)
        uso
        exit 0
        ;;
    -d)
        shift
        destino="$1"
        shift
        ;;
     *)
        directorios+=("$1")
        shift
        ;;
  esac
done

if [ -z $destino ] || [ ! -d $destino ] ; then
  echo "Error con destino. Mira el uso (-help)"
  exit 1
fi

for directorio in ${directorios[@]} ; do
  if [ ! -d $directorio ] ; then
    echo "no existe el directorio ${directorio}"
    continue;
  fi
  validos+=($directorio)
done

directorios=(${validos[@]})

for directorio in ${directorios[@]} ; do
  basename=$(basename "$directorio")
  tar -czf "${destino}/${basename}_bkp_$(date +%Y%m%d).tar.gz" $directorio
done
