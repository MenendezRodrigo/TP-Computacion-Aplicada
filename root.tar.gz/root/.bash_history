history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
ls
ping 8.8.8.8
ip -br a
ping localhost
ping 8.8.8.8
ping google.com
hostname
hostnamectl set-hostname hostname
ping google.com
hostname
hostnamectl set-hostname TPServer
sudo apt update -y
vi /etc/hosts
sudo apt update -y
ping google.com
ping firefox.com
ip route
ping -c3 8.8.8.8
ping -c3 google.com
ping google.com
ping -c3 google.com
cat /etc/resolv.conf
apt update
nslookup deb.debian.org 10.185.50.202
ping deb.debian.org
ping -c3 cdn2-fastly.deb.debian.org
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/apt/sources.list
apt update -y
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt update -y
vi /etc/apt/sources.list
apt update -y
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt full-upgrade 
apt clean
cat /etc/*relesase*
cat /etc/*release*
apt clean
apt update
shutdown now
apt update
apt full-upgrade
apt full-upgrade -y
sed -i "s#http://security.debian.org/debian-security#http://archive.debian.org/debian-security#" /etc/apt/sources.list
apt update
apt full-upgrade -y
apt install ssh
apt install ssh -y
pwd
vi /etc/ssh/sshd_config
systemctl status ssh
sudo systemctl enable --now ssh
systemctl status ssh
systemctl restart ssh
vi /etc/ssh/sshd_config
ssh-keygen -h
ssh-keygen --help
man ssh-keygen
man ssh-keygen
ssh-keygen 
ls -l .ssh/
ls -ld .ssh/
ls -l .ssh/
ls
cd .ssh
ls
mkdir authored_keys
ls -l
chmod 600 authored_keys/
ls -l
cp id_rsa.pub authored_keys/
ls
ls
ls
rm -fr authored_keys/
cat id_rsa.pub >> authored_keys
ls -l
chmod 600 authored_keys 
ls -l
ls
cd ..
ls
systemctl restart ssh
ls
ls
cat .ssh/authored_keys 
cat id_rsa.pub
cat .ssh/id_rsa.pub
apt search apache
apt search apache << less





apt search apache < less
apt search apache >> aca
less aca
apt install apache -y
apt install apache2 -y
apache2 --version
apache --version
apache2ctl --version
apache2 -v
apt update
apt upgrade apache2
apache2 -v
apt install php -y
php -v
apt update
ls -l 
rm -f aca
clear
ls
apt depends apache2
ls -l /var/www/html/
cat /var/www/html/index.html 
cat /var/www/html/index.html 
systemctl show apache2
systmectl status apache2
systmectl status apache
systmectl status apache2
systemctl status apache2
systemctl cat apache2
apachectl status
ls -l /var/www/html/index.html 
ls
man tar
ls
tar -xzvf Material_Adicional_TPVMCA.tar.gz 
ls -l
ls
ls Material_Adicional_TPVMCA
ls .ssh
echo "" > .ssh/authored_keys 
cat Material_Adicional_TPVMCA/clave_publica.pub >> .ssh/authored_keys 
ls
ls .ssh
rm -f .ssh/id_rsa .ssh/id_rsa.pub
ls -l
ls -l .ssh
cat .ssh/authored_keys 
vi .ssh/authored_keys 
clear
ls
cd Material_Adicional_TPVMCA/
ls
cp index.php logo.png /var/www/html/
ls
ls -l /var/www/html
rm -f /var/www/html/index.html 
ls -l /var/www/html/index.php 
ls -l /var/www/html/
systemctl restart apache2
curl http://localhost
curl http://localhost:80
curl http://localhost:80
systemctl status apache2
vi /etc/apache2/apache2.conf 
ls -l /etc/apache2
selinux
semanage
ls li
vi /etc/apache2/sites-enabled/
ss -tulnp 
ls -l /etc/apache2
cat /etc/apache2/ports.conf 
systemctl status apache2
curl -i http://localhost/
tail -n 20 /var/log/apache2/error.log 
cat /var/www/html/index.php 
apt search mariadb
apt install mariadb
apt search mariadb > aca
ls
cat aca 
less aca
apt install mariadb-server -y
systemctl status mariadb.service 
ss -tulnp 
ls
cat /etc/mysql/mariadb.cnf 
ls
file db.sql 
less db.sql 
mysql < db.sql 
curl http://localhost
ls
curl -i http://localhost
ls
cat /var/log/apache2/error.log 
systemctl restart mariadb.service 
curl -i http://localhost
apt install php-mysql 
systemctl restart mariadb.service apache2.service 
curl -i http://localhost
systemctl status NetworkManager.service
systemctl status NetworkManager.service
nmcli
nmcli c
systemctl 
ls -l /etc/network
cat /etc/network/interfaces
ls -l /etc/network/if-up.d/
ls /etc/network/interfaces.d/
ip a
ip route
ifdown enp0s3 
vi /etc/network/interfaces
ifup enp0s3 
ip a
systemctl status networkink
systemctl status networking
vi /etc/network/interfaces
systemctl enable --now mariadb@.service 
shutdown now
