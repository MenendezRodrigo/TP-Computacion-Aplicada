# Compose sequences for VISCII
